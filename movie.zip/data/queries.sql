1. What is the first film of Elizabeth Taylor? =`There's One Born Every Minute'.
2. What is the first film after `Cleopatra' in which El.Taylor costrarred with
Richard Burton? =`The VIPs'.
3. How many times as El.Taylor been nominiated for Best actress Oscar? =5.
4. Name a Musical in which El.taylor stars? = `A Little Night Music'.
5. Who portrays El.Taylor's sister in `Nationaal Velvet'? = Angela Lansbury.
